%--------------------------------------------------------------------------
% Article: Employing structural and statistical information to learn 
% dictionary(s) for single image super-resolution in sparse domain 
% Signal Processing: Image Communication, vol. 48, pp. 63-80, Oct. 2016.
%
% Authors: Srimanta Mandal, Anil K. Sao
% email: srimanta_mandal@students.iitmandi.ac.in; anil@iitmandi.ac.in

% This code performs super resolution  
%--------------------------------------------------------------------------


clc;
clear;
addpath(genpath('Codes'));


Test_image_dir     =    'Data\SR_test_images\My_data\';

psf = fspecial('gauss', 7, 1.6);          % The simulated PSF
 


scale = 3;                                % Downsampling factor 3
nSig  = 0;                                % The standard deviaion of the additive Gaussian noise;
method = 2 ;                              % 1 for SSD , 2 for SSD-EP


if nSig == 0
    Output_dir = 'Results\Noiseless'; 
else
    Output_dir = 'Results\Noisy';     
end

if ~exist(Output_dir,'dir')
        mkdir(Output_dir);
end

image_name         =  'Butterfly.tif';    % input the test image name;

[im PSNR SSIM]   =   Image_SR(method, nSig, psf, scale, Output_dir, Test_image_dir, image_name);
fprintf('%s: PSNR = %3.2f  SSIM = %f\n', image_name, PSNR, SSIM); 


