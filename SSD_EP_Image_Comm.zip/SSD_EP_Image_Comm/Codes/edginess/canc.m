function[s1]=canc(p2,sigma)
[ r c]=size(p2);
t=sqrt(2*pi)*power(sigma,3);
t1=2*power(sigma,2);
for i=1:r
        d1=floor(r/2);
	g(i)=(-(i-d1)/t)*exp(-(i-d1)*(i-d1)/t1);
end
t2=0;
for j=1:c
	t2=t2+1;
	edge=conv(g,p2(:,j));
        d2=d1+r-1;	
	s1(:,t2)=edge(d1:d2);	
end
