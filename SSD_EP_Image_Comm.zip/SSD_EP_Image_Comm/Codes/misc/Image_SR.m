function [im PSNR SSIM]   =  Image_SR(method, nSig, psf, scale, Output_dir, Test_image_dir, image_name)

par.method    =   method;                

load Data/Dictionary/PCA_D2;
load Data/Dictionary/centroids2;

if method ==1
    pre = 'SSD_';
else
    pre = 'SSD_EP_';
end

if nSig == 0
        par.tau       =   0.08;
        par.c1        =   0.7;
        par.lamada    =   5.5;
        par.nIter     =   920;
else
        par.tau       =   0.66;
        par.c1        =   3.4;
        par.lamada    =   0.8;
        par.nIter     =   320;
end

par.nSig      =   nSig;
par.scale     =   scale;
par.psf       =   psf;
par.eps       =   2e-6;

par.PCA_D0      =   PCA_D0;
par.PCA_D30     =   PCA_D30;
par.PCA_D60     =   PCA_D60;
par.PCA_D90     =   PCA_D90;
par.PCA_D120    =   PCA_D120;
par.PCA_D150    =   PCA_D150;
par.Codeword0   =   centroids0;
par.Codeword30  =   centroids30;
par.Codeword60  =   centroids60;
par.Codeword90  =   centroids90;
par.Codeword120 =   centroids120;
par.Codeword150 =   centroids150;


par.nblk      =   10;
par.I         =    double( imread(fullfile(Test_image_dir, image_name)) );
LR            =    Blur('fwd', par.I, par.psf);
LR            =    LR(1:par.scale:end,1:par.scale:end,:); 


par.LR        =    Add_noise(LR, par.nSig);   
par.B         =    Set_blur_matrix( par );       
        
pp            =   'LR_';
fname         =    strcat(pp, image_name);
imwrite(par.LR./255, fullfile(Output_dir, fname));

pp           =   'BC_';
fname        =   strcat(pp, image_name);
BCim         =   imresize(par.LR, par.scale, 'bicubic');
imwrite(BCim./255, fullfile(Output_dir, fname));
   

[im PSNR SSIM]   =   SSD_Superresolutionm( par );
fname            =   strcat(pre, image_name);
imwrite(im./255, fullfile(Output_dir, fname));
