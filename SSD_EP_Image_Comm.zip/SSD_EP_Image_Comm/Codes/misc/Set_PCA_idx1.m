function  [D0, PCA_idx, s_idx, seg, ang_idx]  =  Set_PCA_idx1( im, par, Arr )

[h  w]     =  size(im);
cls_num    =  size( par.Codeword0, 2 );%
LP_filter  =  fspecial('gaussian', 7, par.sigma);
lp_im      =  conv2( LP_filter, im );
lp_im      =  lp_im(4:h+3, 4:w+3);
hp_im      =  im - lp_im;

b       =  par.win;
s       =  par.step;
N       =  h-b+1;
M       =  w-b+1;

r       =  [1:s:N];
r       =  [r r(end)+1:N];
c       =  [1:s:M];
c       =  [c c(end)+1:M];
L       =  length(r)*length(c);
X       =  zeros(b*b, L, 'single');


% For the Y component
k    =  0;
for i  = 1:b
    for j  = 1:b
        k    =  k+1;        
        blk    =  hp_im(r-1+i,c-1+j);
        X(k,:) =  blk(:)';        
    end
end
PCA_idx   =  zeros(L, 1);
ang_idx     =  rand(L,1);%%

m     =  mean(X);
d     =  ( X - m( ones(size(X,1),1), :) ).^2;     
v     =  sqrt( mean( d ) );
[a, ind]  =   find( v<par.delta );


set         =  [1:L];
set(ind)    =  [];
L2          =  size(set,2);
angu = zeros(L2,1);

for i = 1:L2
    
    wx            =   X(:, set(i));
   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    patch = reshape(wx,b,b);
    [Fx,Fy]=gradient(patch);
    F=[Fx(:),Fy(:)];
    [~,~,V] = svd(F);
    angle=atand(V(2,1)/V(1,1));
    if sign(angle)==-1
        angle=angle+180;
    end
    angu(i,:)=angle;
    if angle>0 && angle<=15
       codewords=par.Codeword0;
       ang_idx(set(i)) = 0;
        
    elseif angle>15 && angle<=45
       codewords=par.Codeword30;
       ang_idx(set(i)) = 30;
    elseif angle>45 && angle<=75
       codewords=par.Codeword60;
       ang_idx(set(i)) = 60;
    elseif angle>75 && angle<=105
       codewords=par.Codeword90;
       ang_idx(set(i)) = 90;
    elseif angle>105 && angle<=135
       codewords=par.Codeword120;
       ang_idx(set(i)) = 120;
    elseif angle>135 && angle<=165
       codewords=par.Codeword150;
       ang_idx(set(i)) = 150;
    else
       codewords=par.Codeword0;
       ang_idx(set(i)) = 0;
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    wx            =   wx(:, ones(1,cls_num));       
    dis           =   sum( (wx - codewords).^2 );        
    [md, idx]     =   min(dis);
    PCA_idx( set(i) )  =   idx;
end

[s_idx, seg]  =   Proc_cls_idx( PCA_idx );
D1 = (par.PCA_D0(:,1)+par.PCA_D30(:,1)+par.PCA_D60(:,1)+par.PCA_D90(:,1)+par.PCA_D120(:,1)+par.PCA_D150(:,1))/6;
D0            =   reshape(D1(:,1), b*b,b*b);     
return;
        