function [pa]   =  structural_clustering( X,Y,b )

Y0=[];Y30=[];Y60=[];Y90=[];Y120=[];Y150=[];
X0=[];X30=[];X60=[];X90=[];X120=[];X150=[];
n=size(X,2);
wb = waitbar(0,'Clustering Structurally...');
parfor i=1:n
    patch = reshape(X(:,i),b,b);
    [Fx,Fy]=gradient(patch);
    F=[Fx(:),Fy(:)];
    [~,~,V] = svd(F);
    angle=atand(V(2,1)/V(1,1));
    if sign(angle)==-1
        angle=angle+180;
    end
%     rad=atan2(V(2,1),V(1,1));
%     if sign(rad)==-1
%         rad=rad+2*pi;
%     end
%     angle=180*rad/pi;
    if angle>0 && angle<=15
        X0 =[X0,X(:,i)];
        Y0 =[Y0,Y(:,i)];
    elseif angle>15 && angle<=45
        X30 =[X30,X(:,i)];
        Y30 =[Y30,Y(:,i)];
    elseif angle>45 && angle<=75
        X60 =[X60,X(:,i)];
        Y60 =[Y60,Y(:,i)];
    elseif angle>75 && angle<=105
        X90 =[X90,X(:,i)];
        Y90 =[Y90,Y(:,i)];
    elseif angle>105 && angle<=135
        X120 =[X120,X(:,i)];
        Y120 =[Y120,Y(:,i)];
    elseif angle>135 && angle<=165
        X150 =[X150,X(:,i)];
        Y150 =[Y150,Y(:,i)];
    else
        X0=[X0,X(:,i)];
        Y0=[Y0,Y(:,i)];
    end
   waitbar(i/n);     
end
close(wb);
pa.X0=X0; 
pa.Y0=Y0;
pa.X30=X30;
pa.Y30=Y30;
pa.X60=X60;
pa.Y60=Y60;
pa.X90=X90;
pa.Y90=Y90;
pa.X120=X120;
pa.Y120=Y120;
pa.X150=X150;
pa.Y150=Y150;


