%--------------------------------------------------------------------------
% Employing structural and statistical information to learn 
% dictionary(s) for single image super-resolution in sparse 
% domain

% Authors: Srimanta Mandal, Anil K. Sao
% email: srimanta_mandal@students.iitmandi.ac.in; anil@iitmandi.ac.in

% This code learn the dictionary(s) by employing statistical and structural
% information
%--------------------------------------------------------------------------


clc;
clear;
close all;
addpath(genpath('Codes'));
TD_path      =   'Data/Train_Data';
lib_dir = strcat('Data/Dictionary/');
 if ~exist(lib_dir,'dir')
        mkdir(lib_dir);
 end


% Set the parameters
cls_num     =   60;
b           =   5;
delta       =   4.5;
psf         =   fspecial('gauss', 7, 1.5);
num_blks    =   400*(b^2)*40;



fpath       =   fullfile(TD_path, '*.tif');
im_dir      =   dir(fpath);
im_num      =   length(im_dir);



X     =  zeros(0);
Y     =  zeros(0);


for  i  =  1 : im_num

    im         =   double( imread(fullfile(TD_path, im_dir(i).name)) );
    [Py Px]    =   Get_patches( im, b, psf );
    X          =   [X, Px];
    Y          =   [Y, Py];
end


m     =  mean(Y);
d     =  (Y-repmat(m, size(Y,1), 1)).^2;
v     =  sqrt( mean( d ) );
[a, idx]  =  find( v>=delta );
[a, idx2] =  find( v<delta );

X0   =   X(:, idx2);
[P0, mx]   =  getpca(X0);
clear X0 Px Py a d m v idx2;

X    =   X(:, idx);
Y    =   Y(:, idx);
N    =   size(X, 2);
P    =   randperm(N)';
num  =   min(N, num_blks);
P    =   P(1:num);
X    =   X(:, P);
Y    =   Y(:, P);
clear P;

[pa]   =  structural_clustering( X,Y,b );

X0=pa.X0;
Y0=pa.Y0;
X30=pa.X30;
Y30=pa.Y30;
X60=pa.X60;
Y60=pa.Y60;
X90=pa.X90;
Y90=pa.Y90;
X120=pa.X120;
Y120=pa.Y120;
X150=pa.X150;
Y150=pa.Y150;
clear pa;

for k=0:30:150
    a1=genvarname(strcat('Y',num2str(k)));
    fprintf('\n\n Clustering structurally similar patches (%d degree) based on their statistical information\n',k);
    [centroids, cls_idx, s_idx, seg, cls_num,~]   =  statistical_clustering( eval(a1), cls_num );
    
    PCA_D    =  zeros(b^4, cls_num);
    
    for  i  =  1 : length(seg)-1
        idx    =   s_idx(seg(i)+1:seg(i+1));    
        cls    =   cls_idx(idx(1));
        a2=genvarname(strcat('X',num2str(k)));
        a3=eval(a2);
        X1     =   a3(:, idx);
        [P, mx]   =  getpca(X1);    
        PCA_D(:,cls)    =  P(:);
    end
    
    PCA_D    =  [P0(:) PCA_D];
    eval(['PCA_D' num2str(k) '=PCA_D' ';']);    
    eval(['centroids' num2str(k) '=centroids' ';']);     
    clear PCA_D centroids;
end
toc;

save(strcat(lib_dir,'\','centroids2.mat'),'centroids0','centroids30','centroids60','centroids90','centroids120','centroids150');
save(strcat(lib_dir,'\','PCA_D2.mat'),'PCA_D0','PCA_D30','PCA_D60','PCA_D90','PCA_D120','PCA_D150');

