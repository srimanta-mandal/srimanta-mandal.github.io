function  [cent, cls_idx, s_idx, seg, cls_num, mse]   =  statistical_clustering( X, cls_num )

b2      =  size(X, 1);
L       =  size(X, 2);
itn     =  12;


P      =  randperm(L);
P2     =  P(1:cls_num);
vec    =  X(:,P2(1:end));


for i = 1 : itn
    
    mse       =  0;
    cent      =  zeros(b2, cls_num);
    cnt       =  zeros(1, cls_num);
    cls_idx   =  zeros(L, 1);
    
    for j = 1 : L
        v     =  X(:, j);
        cb    =  repmat(v,1,cls_num);
        dis   =  sum((vec-cb).^2);
        [val ind]      =   min( dis );
        cent(:, ind)   =   cent(:, ind) + v;
        cnt( ind )     =   cnt( ind ) + 1;
        
        cls_idx( j )   =   ind;
        mse            =   mse + val;
    end

    cnt   =  cnt + eps;
    wei   =  repmat(cnt, b2, 1);
    vec   =  cent./wei;    
    mse   =  mse/L/b2;
    disp( sprintf('clustering %d th loop, mse = %f', i, mse) );
    
end

cent   =  vec;


[idx  s_idx]    =  sort(cls_idx);
idx2   =  idx(1:end-1) - idx(2:end);
seq    =  find(idx2);
seg    =  [0; seq; length(cls_idx)];
