function [tau] = threshold_para (X, idx, yes, rat, b)

X = X(:,idx);
R = zeros(size(X,2),1);

for j = 1:size(X,2)
    wx = X(:,j);
    patch = reshape(wx,b,b);
    [Fx,Fy]=gradient(patch);
    F=[Fx(:),Fy(:)];
    [~,S,~] = svd(F);
    s = diag(S);
    r = s(1)/s(2);
    R(j) = r;
end
R1 = R';
t = 1./R1;
tau = repmat(t,b*b,1);
% if yes ==1
%     r2 = min(R);
%     if rat>6 && rat<=12
%         tau = 1/r2 + rat/10;
%         
%     elseif rat>12
%         tau = 1/r2 + rat/10 + rat/12;
%     elseif rat<3
%         tau = 1/r2 - rat/10;
%         
%     elseif rat>3 && rat<6
%         tau = 1/r2 + rat/10;
%     end
% else
%     r2 = max(R);
%     if r2>=30
%         tau = 1/r2 + 0.05;
%     elseif r2<=10
%         tau = 1/r2 - 0.02;
%     else
%         tau = 1/r2;
%     end
% end


