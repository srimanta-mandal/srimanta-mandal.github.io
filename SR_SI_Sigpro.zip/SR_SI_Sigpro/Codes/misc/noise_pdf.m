function R = noise_pdf(type,M,N,s,a,b)

% Valid values for TYPE and parameters A and B are:
% 'uniform'        Uniform random numbers in the interval (A,B). 
%                  The default values are (0,1).
%
% 'guassian'       Gaussian random numbers with mean A and standard
%                  deviation B.The default values are A = 0, B = 1.
%
% 'salt & pepper'  Salt and pepper numbers  of amplitude 1 with probability 
%                  Pa  = A, and amplitude 0 with probability Pb = B. The 
%                  default values are Pa = Pb = A = B = 0.05. Note that the
%                  noise has values 0(with probability Pa = A) and 1(with
%                  probability Pb = B), so scaling is necessary if values
%                  other than 0 and 1 are required. The noise matrix R is
%                  assigned three values. If R(x,y) = 0, the noise at (x,y)
%                  is pepper(black). If R(x,y ) = 1, the noise at (x,y) is
%                  salt(white). If R(x,y) = 0.5, there is no noise assigned
%                  to coordinates (x,y).
%
% 'lognormal'      Lognormal numbers with offset A and shape parameter B.
%                  The defaults are A = 1 and B = 0.25.
%
% 'rayleigh'       Rayleigh noise with parameters A and B. The default 
%                  values are A = 0 and B = 1.
%
% 'exponential'    Exponential random numbers with parameter A. The default
%                  value is A = 1.
% 
% 'erlang'         Erlang(gamma) random numbers with parameters A and B. B
%                  must be a positive integer. The defaults are A = 2 and B
%                  = 5. Erlang random numbers are approximated as the sum
%                  of B exponential random numbers.
%
% set default values.
if nargin == 1
    a = 0; b = 1;
    M = 1; N = 1;
elseif nargin == 3
    a = 0; b = 1;
end

seed  =  0;
randn( 'state', seed );

%as we need only small letters as the type so...
switch lower(type)
    case 'uniform'
        R = a + (b-a)*rand(M,N,s);
    case 'gaussian'
        R = a + b*randn(M,N,s);
    
    case 'lognormal'
        if nargin<=3
            a = 1; b = 0.25;
        end
        R = a*esp(b*randn(M,N,s));
    case 'rayleigh'
        R = a + (-b*log(1-rand(M,N,s))).^0.5;
    case 'exponential'
        if nargin <= 3
            a = 1;
        end
        if a <= 0
            error('the value of a must b positive for exponential operation')
        end
        k = -1/a
        R = k*log(1 - rand(M,N,s));
    case 'erlang'
        if nargin <= 3
            a = 2; b = 5;
        end
        if (b ~= round(b)| b <= 0)
            error('Parameter b should b a negative value for erlang')
        end
        k = -1/a;
        R = zeros(M,N,s);
        for j = 1:b
            R = R + k*log(1 - rand(M,N,s));
        end
    otherwise 
        error('Unknown distribution type.')
end
        
        
        
