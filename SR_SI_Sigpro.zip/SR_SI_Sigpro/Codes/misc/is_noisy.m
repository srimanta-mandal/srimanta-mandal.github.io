function [n,yes,mr,rat] = is_noisy (par)

b=6;
LR = par.LR; 
psf = par.psf;
[Py  Px]  =  Get_patches( LR, b, psf );

m     =  mean(abs(Py));
d     =  (Py-repmat(m, size(Py,1), 1)).^2;
v     =  sqrt( mean( d ) );
delta = min(v) + 4;

[~, idx]  =  find( v>=delta );
[~, idx1] =  find( v<delta );

Px1 = Px;
Px(:,idx)=[];


R = zeros(size(Px,2),1);
for j = 1:size(Px,2)
    wx = Px(:,j);
    patch = reshape(wx,b,b);
    [Fx,Fy]=gradient(patch);
    F=[Fx(:),Fy(:)];
    [~,S,~] = svd(F);
    s = diag(S);
    r = s(1)/s(2);
    R(j) = r;
end
R = R(isfinite(R(:, 1)));
R = sort(R);
r1 = mean(R);

mr = min(R);
if mr<=2
    ct = mr+0.5;
else
    ct = mr+1;
end

n1 = find(R>=ct);
n2 = find(R<ct);

if size(n1,1)<size(n2,1)
    yes = 1;
    r2 = min(R);
    rat = size(n2,1)/size(n1,1);
    
    if rat>6 && rat<=12
        n = 1/r2 + rat/10;        
    elseif rat>12
        n = 1/r2 + rat/10 + rat/12;
    elseif rat<3
        n = 1/r2 - rat/10;        
    elseif rat>3 && rat<6
        n = 1/r2 + rat/10;
    end
    
elseif size(n1,1)>size(n2,1)
    yes = 0;
    r2 = max(R);
    rat = size(n2,1)/size(n1,1);
    if r2>=30
        n = 1/r2 + 0.05;
    elseif r2<=10
         n = 1/r2 - 0.02;
    else
        n = 1/r2;
    end
else
    yes = 0;
    r2 = r1;
    rat = size(n2,1)/size(n1,1);
    n = 1/r2;
end


