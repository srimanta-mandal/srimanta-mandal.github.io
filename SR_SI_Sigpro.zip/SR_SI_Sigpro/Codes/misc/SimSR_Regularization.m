function  [im_out]  =  SimSR_Regularization( im, opts, Dict, blk_arr, wei_arr )
[h w ch]   =   size(im);
b          =   opts.win;
b2         =   b*b*ch;
k          =   0;
s          =   opts.step;
A          =   Dict.D0;
PCA_D      =   Dict.PCA_D;
PCA_idx    =   Dict.cls_idx;
s_idx      =   Dict.s_idx;
seg        =   Dict.seg;

N     =  h-b+1;
M     =  w-b+1;
L     =  N*M;
r     =  [1:s:N];
r     =  [r r(end)+1:N];
c     =  [1:s:M];
c     =  [c c(end)+1:M];
X     =  zeros(b*b,L,'single');
for i  = 1:b
    for j  = 1:b
        k    =  k+1;
        blk  =  im(i:h-b+i,j:w-b+j);
        blk  =  blk(:);
        X(k,:) =  blk';            
    end
end

X_m     =  zeros(length(r)*length(c),b*b,'single');
X0 = X';
for i = 1:opts.nblk
   v        =  wei_arr(:,i);
   X_m      =  X_m(:,:) + X0(blk_arr(:,i),:) .*v(:, ones(1,b2));
end
X_m=X_m';

ind        =   zeros(N,M);
ind(r,c)   =   1;
X          =   X(:, ind~=0);
N          =   length(r);
M          =   length(c);
L          =   N*M;
Y          =   zeros( b2, L );

idx        =   s_idx(seg(1)+1:seg(2));

tau = opts.tt;

if opts.yes == 1 && opts.scale ==4 && opts.rat>=5    
    tau = 0.8;
end

if opts.yes == 1
        if opts.rat<=5
            Y(:, idx)    =   A'*soft( A*X(:,idx), tau );            
        else
             Y(:, idx)    =   A'*soft( A*X_m(:,idx), tau );             
        end
else
        Y(:, idx)    =   A'*soft( A*X(:,idx), tau );  
end


for   i  = 2:length(seg)-1   
    idx    =   s_idx(seg(i)+1:seg(i+1));    
    cls    =   PCA_idx(idx(1));
    P      =   reshape(PCA_D(:, cls), b2, b2);
        
   
    if opts.yes == 1 && opts.rat>5
        tau = threshold_para (X, idx, opts.yes, opts.rat, opts.win);        
    elseif opts.yes == 1 && opts.scale ==4 && opts.rat>5
        tau = 0.8;
    end
    
   
    if opts.yes == 1
        if opts.rat<=5
            Y(:, idx)    =   (P'*soft(P*(X(:, idx)-X_m(:,idx)), tau)) + X_m(:,idx);
        else
             Y(:, idx)    =   (P'*soft(P*X_m(:,idx), tau)+X_m(:,idx))/2;
           
        end
    else
        Y(:, idx)    =   (P'*soft(P*(X(:, idx)-X_m(:,idx)), tau)) + X_m(:,idx);
    end
  
   
end

im_out   =  zeros(h,w);
im_wei   =  zeros(h,w);
k        =  0;
for i  = 1:b
    for j  = 1:b
        k    =  k+1;
        im_out(r-1+i,c-1+j)  =  im_out(r-1+i,c-1+j) + reshape( Y(k,:)', [N M]);
        im_wei(r-1+i,c-1+j)  =  im_wei(r-1+i,c-1+j) + 1;       
    end
end
im_out    =  im_out./(im_wei+eps);
return;



