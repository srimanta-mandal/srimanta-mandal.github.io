function [im_out PSNR SSIM RMSE]   =  SimSR_Superresolution( par )
time0         =   clock;
par.step      =   2;
par.win       =   6;
par.cls_num   =   64;
par.s1        =   25;
par.hp        =   75;

s             =   par.scale;
lr_im         =   par.LR;
[lh lw ch]    =   size(lr_im);
hh            =   lh*s;
hw            =   lw*s;
hrim          =   uint8(zeros(hh, hw, ch));
ori_im        =   zeros(hh,hw);

if  ch == 3
    lrim           =   rgb2ycbcr( uint8(lr_im) );
    lrim           =   double( lrim(:,:,1));    
    b_im           =   imresize( lr_im, s, 'bicubic');
    b_im2          =   rgb2ycbcr( uint8(b_im) );
    hrim(:,:,2)    =   b_im2(:,:,2);
    hrim(:,:,3)    =   b_im2(:,:,3);
    if isfield(par, 'I')
        ori_im         =   rgb2ycbcr( uint8(par.I) );
        ori_im         =   double( ori_im(:,:,1));
    end
else
    lrim           =   lr_im;
    
    if isfield(par, 'I')
        ori_im             =   par.I;
    end
end
hr_im    =   imresize(lrim, s, 'bicubic');
hr_im    =   Superresolution(lrim, par, ori_im, hr_im, 0, 2);
if par.rat<=5
    hr_im    =   Superresolution(lrim, par, ori_im, hr_im, 1, 2);
end

if isfield(par,'I')
   [h w ch]  =  size(par.I);
   [PSNR,RMSE]      =  csnr( hr_im(1:h,1:w), ori_im, 0, 0 );
   SSIM      =  cal_ssim( hr_im(1:h,1:w), ori_im, 0, 0 );
end
if ch==3
    hrim(:,:,1)  =  uint8(hr_im);
    im_out       =  double(ycbcr2rgb( hrim ));
else
    im_out  =  hr_im;
end
fprintf('Total elapsed time = %f min\n', (etime(clock,time0)/60) );
return;


function  hr_im     =   Superresolution(lr_im, par, ori_im, hr_im0, flag, K)
hr_im      =   imresize( lr_im, par.scale, 'bicubic' );
[h   w]    =   size(hr_im);
[h1 w1]    =   size(ori_im);
y          =   lr_im;
[ht wd]   = size(y);

lamada     =   par.lamada;
BTY       =   par.B'*y(:);
BTB       =   par.B'*par.B;
cnt       =   0;
if  flag==1  
     hr_im    =  hr_im0;
end

for k    =  1:K    
    Dict        =   KMeans_PCA( hr_im, par, par.cls_num );
       
    [blk_arr wei_arr]    =   Block_matching( hr_im, par); 

    Reg          =   @(x)SimSR_Regularization(x, par, Dict, blk_arr, wei_arr );        
    f            =   hr_im;
        
    for  iter    =   1 : par.iters
        cnt      =   cnt  +  1;           
        f_pre    =   f;
   
        if (mod(cnt, 40) == 0)
            if isfield(par,'I')
                [PSNR,RMSE]     =  csnr( f(1:h1,1:w1), ori_im, 0, 0 );
                fprintf( 'SimSR super-resolution, iter. %d : PSNR = %f, RMSE = %f\n', cnt, PSNR, RMSE );
            end
        end

        f        =   f_pre(:);
        for i = 1:par.n
            f    =   f + lamada.*(BTY - BTB*f);
        end
        f        =  Reg( reshape(f, h,w) );    
        
         par.angle='g';  
        sigma1   =  1;
        sigma2   =  0.4;
        angle    =  str2double(par.angle);
        if isnan(angle)
            angle=0;
        end
              
        image = imresize(f,[ht wd],'bicubic');

        if rem(ht,2)~=0 || rem(wd,2)~=0
            image=imresize(image,[ht-rem(ht,2) wd-rem(wd,2)]);
            y=imresize(y,[ht-rem(ht,2) wd-rem(wd,2)]);
        end
        [e1,e3,~]  =   direction(image,sigma1,sigma2,angle);
        [e2,e4,~]  =   direction(y,sigma1,sigma2,angle);
        if par.angle == 'g'
            e= sqrt(e1.^2 + e3.^2);   
            ee= sqrt(e2.^2 + e4.^2);  
        else
            e  = e1;
            ee = e2;
        end

        beta    =   0.001;
        f1 = imresize((e - ee),[h w], 'bicubic');
        f    =  f + beta.* f1;   
        f    =  Reg( reshape(f, h,w) );
        
        
    end
    hr_im   =  f;
end


