function[s1]=gscol(p1,sigma)
[r c]=size(p1);
t=sqrt(2*pi)*sigma;
t1=2*power(sigma,2);
     for i=1:r
     d1=floor(r/2);
    g(i)=(1/t)*exp(-(i-d1)*(i-d1)/t1);
     end
    t2=0;
   for j=1:c
     t2=t2+1;
     smooth=conv(g,p1(:,j));

      d2=d1+r-1;
    s1(:,t2)=smooth(d1:d2);	
   end
  