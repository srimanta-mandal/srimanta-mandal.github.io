% This the function which apply the smmothing function in the given direction
% and derivative operator in orthogonal direction
% sigma1 is the variance of gaussian function which used for smothing
% sigma2 is the varinace of gaussian function 
% Derivative of this function  is used as derivative opearator.

% A  is the parital evidence along the  given angle
% B is the partial evidence along  the orthogonal direction of given angle
% C is  the resultant  gradient image

function[a,b,c]= direction(im,sigma1,sigma2,angle)

%sigma1;
image=imrotate(im,angle,'bilinear');
imR=im2double(image);
p1=gscol(imR,sigma1);  % smoothing along the orthogonal to given direction
a=canr(p1,sigma2);     
p2=gsrow(imR,sigma1);
b=canc(p2,sigma2);

a=imrotate(a,-angle);
b=imrotate(b,-angle);

[R C ]= size(a);
[r c ]= size(im);

c1= ceil(ceil(C/2)-ceil(c/2));
c2=ceil(ceil(C/2)+ceil(c/2));

r1=ceil(ceil(R/2)-ceil(r/2));
r2=ceil(ceil(R/2)+ceil(r/2));

a=a([r1+1 : r2],[c1+1 :c2]);     % a is the partial edge evidence in the  give direction
b=b([r1+1 : r2],[c1+1 :c2]);     % b is the partial edge evidence in the orthogoal to given direction

a=a([1 : r],[1 :c]);
b=b([1 : r],[1 :c]);
c=sqrt(a.^2+b.^2);


