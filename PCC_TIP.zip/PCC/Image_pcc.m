function [im PSNR SSIM]   =  Image_pcc(percent, nSig, Output_dir, Test_image_dir, image_name)
        
load Data/Dictionary/raw_p5;
pre  = 'PCC_';

par.nSig      =   nSig;
par.eps       =   2e-6;
par.PCA_D     =   Dict;
par.Codeword  =   centroids;
par.seg       =   seg;
par.win     =   sqrt(size(Dict,1));
par.step    =   3;


par.I = double( imread(fullfile(Test_image_dir, image_name)) );
[h w]  =  size(par.I);
if nSig~=0
    par.I2 = par.I+nSig*randn(h,w);
else
    par.I2 = par.I;
end

per = percent;

rng default

Pos=randperm(h*w);
Mask=ones(h,w); 
p = round(h*w*per/100);
Mask(Pos(1:p))=0; 
par.I1 = par.I2.*Mask;
par.Mask = Mask;
par.p    =  p;
par.pos  =  Pos;
par.per = per;


lname  =  strcat(num2str(per),'PC_im',image_name);
imwrite(par.I1./255,fullfile(Output_dir, lname));
[RMSE, PSNR]     =  csnr( par.I1(1:h,1:w), par.I, 5, 5 );
SSIM      =  cal_ssim( par.I1(1:h,1:w), par.I, 5, 5 );
fprintf( 'Point Cloud at %d percent of %s Image: RMSE = %f, PSNR = %f SSIM = %f\n',per,image_name,RMSE,PSNR,SSIM);
                
[im RMSE PSNR SSIM]   =   sparse_pcc( par );
fname            =   strcat(num2str(per),'p',num2str(par.win), image_name);
imwrite(im./255, fullfile(Output_dir, fname));
fprintf('PCC @ %d percent of %s: RMSE = %f PSNR = %3.2f  SSIM = %f\n',per,image_name,RMSE,PSNR,SSIM);
fprintf('\n'); 


m_name = image_name(1:end-4);
gname = strcat(pre, 'nSig',num2str(nSig),'_', m_name);
save( strcat(Output_dir, '\',gname,'.mat'),'RMSE','PSNR','SSIM');
end
