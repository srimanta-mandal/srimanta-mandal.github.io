clc;
clear all;
close all;


Test_image_dir     =    'Data\Test_data\';


image_name = 'n_Cones.png';
percent = 15; % Percentage of depth data to remove from image randomly
nSig = 0;  % The standard deviation of the additive Gaussian noise;


if nSig == 0
    Output_dir         =    'PCC\Noiseless';    % Where the output image will be generated;
else
    Output_dir         =    'PCC\Noisy';        % Where the output image will be generated;
end

if~exist(Output_dir,'dir')
    mkdir(Output_dir);
end

   
[im PSNR SSIM]   =   Image_pcc(percent, nSig, Output_dir, Test_image_dir, image_name);
        

