function [im_out RMSE PSNR SSIM]   =  sparse_pcc( par )


if isfield(par, 'I')
   ori_im             =   par.I;
end   

hr_im     =   par.I1;
[h   w]   =   size(hr_im);
[h1 w1]   =   size(ori_im);

[P]    =   Set_dict_idx( hr_im, par, par.Codeword, 0 );
[hr_im] = restore(hr_im, P, par);
f             =    hr_im;


[h w] = size(f);
fs = f (:);
mxv = max(max(par.I1));
mnv = min(min(par.I1));

hv = find(fs>mxv);
lv = find(fs<mnv);
fs(hv,:) = mxv;
fs(lv,:) = mnv;
f = reshape(fs,[h,w]);
hr_im = medfilt2(f);


if isfield(par,'I')
   [h w ch]  =  size(par.I);
   [RMSE,PSNR]      =  csnr( hr_im(1:h,1:w), ori_im, 5, 5 );
   SSIM      =  cal_ssim( hr_im(1:h,1:w), ori_im, 5, 5 );
end

im_out  =  hr_im;   

return;


