function  [P]  =  Set_dict_idx( hr_im, par, codewords, flag )

im = hr_im;
Arr = flag;

[h  w]     =  size(im);
cls_num    =  size( codewords, 2 );
b       =  par.win;
s       =  par.step;
N       =  h-b+1;
M       =  w-b+1;

r       =  [1:s:N];
r       =  [r r(end)+1:N];
c       =  [1:s:M];
c       =  [c c(end)+1:M];
L       =  length(r)*length(c);
X       =  zeros(b*b, L, 'double');
Mask  =  zeros(b*b,L,'double');
Mask1 = par.Mask;

k    =  0;
for i  = 1:b
    for j  = 1:b
        k    =  k+1;
        blk    =  im(r-1+i,c-1+j);
        X(k,:) =  blk(:)';        
        msk    = Mask1(r-1+i,c-1+j);
        Mask(k,:)= msk(:)';
    end
end



codewords1 = par.Codeword;
Dict1 = par.PCA_D;
P=[];

Wsum=[];
wt=waitbar(0,'Please Wait...');

for i = 1:L
    waitbar(i/L);
    patch = X(:, i);
    pos = find(Mask(:,i));
    wx1 = patch (pos,:);
    sw = sum(wx1);
    Wsum = [Wsum,sw];
    
    if sw==0
        ff = find(Wsum);
        if isempty(ff)
            pp = L-i+1;
        else
            pp = ff(:,end);
        end
        patcht = X(:, pp);
        pos = find(Mask(:,pp));
        wx = patcht (pos,:);
    else
        wx = wx1;        
    end
    fwx = wx;
    wx            =   wx(:, ones(1,cls_num));       
    codewords = codewords1(pos,:);
    dis           =   sum( (wx - codewords).^2 ); 
 
    [md, idx]     =   min(dis);
    dict = Dict1(:,par.seg(idx,:)+1:par.seg(idx+1,:));
    rr = randperm(2000);
    if size(dict,2)<2000
        D = dict(:,1:end);
    else
        D = dict(:,rr);
    end
    
    nSig = par.nSig;
   if nSig ==0
       nS = 1;
   else
       nS = nSig*4;%1.1;
   end
    [n,K]=size(D);
    E2 = (nS)^2*n;    
    maxNumCoef = n/2;
    A = sparse(size(D,2),1);
    Mpos = pos;    
    E2M=E2*length(Mpos)/n;
    Dict=D(Mpos,:);
    W=1./sqrt(diag(Dict'*Dict)); 
    Dict=Dict*diag(W);
    x = fwx;    
    residual=x;
    indx = [];
    a = [];
    currResNorm2 = sum(residual.^2);
    j = 0;
    while currResNorm2>E2M && j < maxNumCoef,
        j = j+1;
        proj=Dict'*residual;
        pos=find(abs(proj)==max(abs(proj)));
        pos=pos(1);
        indx(j)=pos;
        a=pinv(Dict(:,indx(1:j)))*x;
        residual=x-Dict(:,indx(1:j))*a;
        currResNorm2=sum(residual.^2);
    end
   if (~isempty(indx))
        A(indx,:)=a;        
        W=double(W);
        A = W.*A;
   end
    D = double(D);
    s = D*A;
    P = [P,s];

end

close(wt);
return;
        